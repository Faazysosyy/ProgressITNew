// Import anime.js
import './anime.min.js';

console.log('Index.js loaded, should have imported anime.js'); 