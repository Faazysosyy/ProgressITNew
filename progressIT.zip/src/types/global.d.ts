interface Window {
  initEmberAnimation: () => HTMLCanvasElement;
}
